package main

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/xml"
	"errors"
	"fmt"
	"html/template"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"runtime"
	"strconv"
	"time"

	"gitlab.com/rendezvousPoint/incentive_calculator/constant"
	"gitlab.com/rendezvousPoint/incentive_calculator/utils/configs"
	"gitlab.com/rendezvousPoint/incentive_calculator/utils/flags"
	"gitlab.com/rendezvousPoint/incentive_calculator/utils/logger"
)

var SMSRequestTemplate = []byte(`<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:sen="http://www.omantel.om/esb/messages/sendnotification">
<soapenv:Header/>
<soapenv:Body>
   <sen:SendNotificationRq>
	  <sen:RequestHeader>
		 <FunctionId>{{.FunctionId}}</FunctionId>
		 <TransactionId>0</TransactionId>
		 <RequestId>OMSIP_{{.RequestId}}</RequestId>
		 <RequestorChannelId>OMSIP</RequestorChannelId>
		 <RequestorUserId>OMSIP</RequestorUserId>
		 <Timestamp>{{.Timestamp}}</Timestamp>
	  </sen:RequestHeader>
	  <sen:RequestBody>
		 <sen:Notification>
			<NotificationType>SMS</NotificationType>
			<NotificationDateTime>{{.NotificationDateTime}}</NotificationDateTime>
			<NotificationLanguage>1</NotificationLanguage>
			<ShortCode>ROP Permit</ShortCode>
			<IsDeliveryStatusRequired>1</IsDeliveryStatusRequired>
			<NotificaitionValidityPeriod>{{.NotificaitionValidityPeriod}}</NotificaitionValidityPeriod>
			<Body>Dear {{.UserId}}, Your OTP is {{.OTP}}

		</Body>
			<BodyCoding>8</BodyCoding>
			<BodyContentType>1</BodyContentType>
			<ReceiverList>
			   <Receiver>{{.Receiver}}</Receiver>
			</ReceiverList>
		 </sen:Notification>
	  </sen:RequestBody>
   </sen:SendNotificationRq>
</soapenv:Body>
</soapenv:Envelope>`)

var client *http.Client
var otpUrl string
var fileName string

type Request struct {
	//Values are set in below fields as per the request
	UserId                      string
	FunctionId                  string
	TransactionId               string
	RequestId                   string
	RequestorChannelId          string
	RequestorUserId             string
	Timestamp                   string
	NotificationType            string
	NotificationDateTime        string
	NotificationLanguage        string
	ShortCode                   string
	IsDeliveryStatusRequired    string
	NotificaitionValidityPeriod string
	Body                        string
	BodyCoding                  string
	BodyContentType             string
	Receiver                    string
	OTP                         string
}

type Response struct {
	XMLName  xml.Name `xml:"http://schemas.xmlsoap.org/soap/envelope/ Envelope"`
	SoapBody *SOAPBodyResponse
}

type SOAPBodyResponse struct {
	XMLName      xml.Name `xml:"Body"`
	Resp         *ResponseBody
	FaultDetails *Fault
}

type Fault struct {
	XMLName     xml.Name `xml:"Fault"`
	Faultcode   string   `xml:"faultcode"`
	Faultstring string   `xml:"faultstring"`
}

type ResponseBody struct {
	XMLName   xml.Name `xml:"Response"`
	RequestID string   `xml:"RequestID"`
	Response  *Body
	Status    string `xml:"Status"`
}

type Body struct {
	XMLName       xml.Name `xml:"Body"`
	Status        string   `xml:"Status"`
	Salary        string   `xml:"Salary"`
	Designation   string   `xml:"Designation"`
	Manager       string   `xml:"Manager"`
	Company       string   `xml:"Company"`
	EmployedSince string   `xml:"EmployedSince"`
}

func init() {

	initEnvConfigs()
	initLogger()
	initFileLogger()
	initHTTPClient()
}

func main() {

	fmt.Println("application is running: config loaded successfully - " + time.Now().String())
	fmt.Println("otp url: " + otpUrl)
	fmt.Println("certificate fileName: " + fileName)

	var Mobile string

	fmt.Printf("Enter Your Mobile Number: ")
	fmt.Scanln(&Mobile)
	fmt.Println("Your Mobile Number is: " + Mobile)

	t := time.Now()
	fmt.Println("Initiating SOAP call...")
	if err := callSOAPClientSteps("TESTUSER", Mobile, 123456); err != nil {
		fmt.Println("SOAP call failed: "+err.Error(), "timeOut: "+time.Since(t).String())
		return
	}

	fmt.Println("SOAP call successfull")
}

func initEnvConfigs() {
	configs.Init(flags.BaseConfigPath() + "/" + flags.Env())
	logger.Info(context.TODO()).Str("env", flags.BaseConfigPath()+"/"+flags.Env()).Msg("initialized configs for env")
}

func initLogger() {

	loggerConfig, err := configs.Get(constant.LoggerConfigFile)
	if err != nil {
		logger.Fatal(context.TODO()).Stack().Err(err).Msg("error loading logger config file, env - " + flags.Env())
	}

	logger.InitLogger(logger.Level(loggerConfig.GetString(constant.LogLevelKey)))
}

func initFileLogger() {

	applicationConfig, err := configs.Get(constant.LoggerConfigFile)
	if err != nil {
		logger.Fatal(context.TODO()).Stack().Err(err).Msg("error loading application config file, env - " + flags.Env())
	}

	err = logger.InitFileLogger(logger.FileConfig{
		EncodeLogsAsJson:      applicationConfig.GetBool(constant.EncodeLogAsJsonKey),
		ConsoleLoggingEnabled: applicationConfig.GetBool(constant.ConsoleLoggingEnabledKey),
		FileLoggingEnabled:    applicationConfig.GetBool(constant.FileLoggingEnabledKey),
		Directory:             applicationConfig.GetString(constant.DirectoryKey),
		Filename:              applicationConfig.GetString(constant.FileNameKey),
		MaxSize:               applicationConfig.GetInt(constant.MaxSizeInMBKey),
		MaxBackups:            applicationConfig.GetInt(constant.MaxBackUpsKey),
		MaxAge:                applicationConfig.GetInt(constant.MaxAgeInDaysKey),
		Compress:              applicationConfig.GetBool(constant.Compress),
	})

	config := logger.FileConfig{
		EncodeLogsAsJson:      applicationConfig.GetBool(constant.EncodeLogAsJsonKey),
		ConsoleLoggingEnabled: applicationConfig.GetBool(constant.ConsoleLoggingEnabledKey),
		FileLoggingEnabled:    applicationConfig.GetBool(constant.FileLoggingEnabledKey),
		Directory:             applicationConfig.GetString(constant.DirectoryKey),
		Filename:              applicationConfig.GetString(constant.FileNameKey),
		MaxSize:               applicationConfig.GetInt(constant.MaxSizeInMBKey),
		MaxBackups:            applicationConfig.GetInt(constant.MaxBackUpsKey),
		MaxAge:                applicationConfig.GetInt(constant.MaxAgeInDaysKey),
		Compress:              applicationConfig.GetBool(constant.Compress),
	}

	if err != nil {
		logger.Fatal(context.TODO()).Err(err).Msg("unable to initialize file logger")
	}

	logger.Info(context.TODO()).Interface("fileConfig", config).Msg("fileConfig: load configuration")
}

func initHTTPClient() {

	applicationConfig, err := configs.Get(constant.ApplicationConfigFile)
	if err != nil {
		logger.FileLogger.Fatal().Stack().Err(err).Msg("initHTTPClient: error loading application config file, env - " + flags.Env())
	}

	certificate := applicationConfig.GetString(constant.HTTPTLSCertificateFileLocation)
	connectTimeout := time.Millisecond * applicationConfig.GetDuration(constant.HTTPConnectTimeoutInMillisKey)
	keepAliveDuration := time.Millisecond * applicationConfig.GetDuration(constant.HTTPKeepAliveDurationInMillisKey)
	maxIdleConnections := applicationConfig.GetInt(constant.HTTPMaxIdleConnectionsKey)
	idleConnectionTimeout := time.Millisecond * applicationConfig.GetDuration(constant.HTTPIdleConnectionTimeoutInMillisKey)
	tLSHandshakeTimeout := time.Millisecond * applicationConfig.GetDuration(constant.HTTPTlsHandshakeTimeoutInMillisKey)
	expectContinueTimeout := time.Millisecond * applicationConfig.GetDuration(constant.HTTPExpectContinueTimeoutInMillisKey)
	timeout := time.Millisecond * applicationConfig.GetDuration(constant.HTTPTimeoutInMillisKey)

	otpUrl = applicationConfig.GetString(constant.OTPEndpoint)
	fileName = certificate

	dialer := &net.Dialer{
		Timeout:   connectTimeout,
		KeepAlive: keepAliveDuration,
	}

	caCert, err := ioutil.ReadFile(certificate)
	if err != nil {
		log.Fatal(err)
	}

	caCertPool := x509.NewCertPool()
	caCertPool.AppendCertsFromPEM(caCert)

	client = &http.Client{
		Transport: &http.Transport{
			DialContext: dialer.DialContext,
			TLSClientConfig: &tls.Config{
				RootCAs: caCertPool,
			},
			MaxIdleConns:          maxIdleConnections,
			IdleConnTimeout:       idleConnectionTimeout,
			TLSHandshakeTimeout:   tLSHandshakeTimeout,
			ExpectContinueTimeout: expectContinueTimeout,
			MaxIdleConnsPerHost:   runtime.GOMAXPROCS(0) + 1,
		},
		Timeout: timeout,
	}

	logger.Info(context.TODO()).Dur("timeout", timeout).Msg("httpConfig: load configuration")
}

func callSOAPClientSteps(userID, mobile string, otp int) error {

	req := populateRequest(userID, mobile, otp)

	httpReq, err := generateSOAPRequest(req)
	if err != nil {
		return err
	}

	_, err = soapCall(httpReq)
	if err != nil {
		return err
	}

	return nil
}

func populateRequest(userId, mobile string, otp int) *Request {

	req := Request{
		UserId:   userId,
		OTP:      strconv.Itoa(otp),
		Receiver: mobile,
	}

	return &req
}

func generateSOAPRequest(req *Request) (*http.Request, error) {
	// Using the var getTemplate to construct request
	template, err := template.New("smsRequest").Parse(string(SMSRequestTemplate))
	if err != nil {
		return nil, errors.New("parsing-" + err.Error())
	}

	doc := &bytes.Buffer{}
	// Replacing the doc from template with actual req values
	err = template.Execute(doc, req)
	if err != nil {
		return nil, errors.New("execute-" + err.Error())
	}

	buffer := &bytes.Buffer{}
	encoder := xml.NewEncoder(buffer)
	err = encoder.Encode(doc.String())
	if err != nil {
		return nil, errors.New("encode-" + err.Error())
	}

	r, err := http.NewRequest(http.MethodPost, otpUrl, bytes.NewBuffer(doc.Bytes()))
	if err != nil {
		return nil, errors.New("request-" + err.Error())
	}

	return r, nil
}

func soapCall(req *http.Request) (*Response, error) {

	resp, err := client.Do(req)
	if err != nil {
		return nil, errors.New("call-" + err.Error())
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, errors.New("readall-" + err.Error())
	}
	defer resp.Body.Close()

	r := &Response{}
	err = xml.Unmarshal(body, &r)
	if err != nil {
		return nil, errors.New("unmarshall-" + err.Error())
	}

	if r.SoapBody.Resp.Status != "200" {
		return nil, err
	}

	return r, nil
}
